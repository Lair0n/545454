namespace Ovchinnikow_PR_22._106.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class WorkSchedules
    {
        [Required]
        [Key]
        public int ID { get; set; }

        [Required]
        public int? StaffID { get; set; }

        [Required]
        [Column(TypeName = "date")]
        public DateTime? Date { get; set; }
        [Required]
        public TimeSpan? StartTime { get; set; }
        [Required]
        public TimeSpan? EndTime { get; set; }

        public virtual Staff Staff { get; set; }
    }
}
